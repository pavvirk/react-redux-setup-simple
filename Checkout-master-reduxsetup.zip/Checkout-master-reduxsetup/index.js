import React from 'react';
import { render } from 'react-dom';
import { Provider } from 'react-redux';
import { createStore } from 'redux';
import { Router, Route, browserHistory } from 'react-router';
import Home from './app/screens/Home';
import 'bootstrap/dist/css/bootstrap.min.css';
import './assets/styles.css';


//Reducer
const initialState= {
  first: 0,
  second: 0,
  result: 0
}

const rootReducer = (state = initialState , action) => {
    switch(action.type) {
      case 'ADD':
      return {...state, result: action.first + action.second};
      default :
      return state;
    }
}




//Store Creater

const store = createStore(rootReducer);


render(
  <Provider store={store}>
    <Router history={browserHistory}>
      <Route path="/" component={Home} />
    </Router>
  </Provider>
  ,
  document.getElementById('container')
);


