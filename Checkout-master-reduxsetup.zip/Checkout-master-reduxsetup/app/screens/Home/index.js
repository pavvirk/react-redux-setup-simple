import React, {Component} from 'react';
import { connect } from 'react-redux';
import itemProd from '../../../assets/data';
// import List from '../Components/ListItem';
// import PackageList from '../Components/Package';

//Function to determine each package items
export const buy = (items) =>{
  const packages = [];
  items.forEach(item => {
      const pac = packages.find(function(pack){
              return pack.price + item.price <= 250;
          });
      if (packages.length && pac) {
          if (pac){
              pac.price += item.price;
              pac.weight += item.weight;
              pac.items.push(item);
          }
      } else {
          packages.push({
              price: item.price,
              weight: item.weight,
              items:[item]
          }); 
      }
  });

  const mean = packages.reduce((tot, curr) => tot + curr.weight, 0)/packages.length;
  packages.forEach((cPack, j) => {
    let ct = cPack.weight;
    cPack.items.forEach((cItem, i) => {

      if(ct > mean){
        const packToInsert = packages.find(p => p.weight < mean && p.price + cItem.price <= 250);
       if(packToInsert) {
        packages[j].weight -= cItem.weight;
        packages[j].price -= cItem.price;
        packages[j].items.splice(i, 1);

        packages[packages.indexOf(packToInsert)].weight += cItem.weight;
        packages[packages.indexOf(packToInsert)].price += cItem.price;
        packages[packages.indexOf(packToInsert)].items.push(cItem);
       }
       ct = ct - cItem.weight;
      }
    })
  });
  return packages;
};

// We can use redux for all the state management but this application which involves 2-3 actions
// For this app not required to import whole redux libraries
// So i am using local state for all the state management 
 class Home extends Component {
  state = {
    item: itemProd, //  Items stored in '/assets/data' where we can update the item
    added: [],
    packages: []
  };

  // Function to capture selected item for Placing order
  handleChange = (event, actionItem)=> {
    if(event.target.checked) {
      this.setState(prevState => ({
        added: [...prevState.added, actionItem]
    }));
    } else {
      this.setState((prevState) => {
       prevState.added.splice(prevState.added.indexOf(actionItem),1);
        return { added: prevState.added };
      });
    }
  }

  placeOrder = () => {
    const pack = buy(this.state.added);
    this.setState({ packages: pack });
    window.scroll(0,0); // For User experience scrolling to top
  }

  changeHandle(event, type) {
    this.setState({
      [type]: event.target.value
    })
  }

  handleAdd() {

  //  this.setState({
  //    result: Number(this.state.first) + Number(this.state.second)
  //  });

    this.props.addNum(Number(this.state.first), Number(this.state.second));
  }



  render() {
    return (
      <div>
        <section className="container">
          <input type="number"  value={this.state.first} onChange={event => this.changeHandle(event, 'first')}/>
          <input type="number"  value={this.state.second} onChange={event => this.changeHandle(event, 'second')}/>
          <div>First - {this.state.first}</div>
          <div>Second - {this.state.second}</div>
          <button onClick={() => this.handleAdd()}> Add</button>
          <div>{this.props.result}</div>
        </section>
      </div>
    );
  }
}

const mapStateToProps = state => ({
  result: state.result
});

const mapDispatchToProps = dispatch=> ({
addNum: (first, second) => dispatch({type: 'ADD', first, second})
});

export default connect(mapStateToProps, mapDispatchToProps)(Home);